package application;


public class Speedo extends OverallDiameter {
    //ask the user what mph they want to check speedo discrepancy at // this should be its own class //declare it as subclass?       

    int MPH = 60;
    double actualSpeed = (overallDiameter2 / overallDiameter1) * MPH;

}
