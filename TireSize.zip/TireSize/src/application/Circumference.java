package application;

public class Circumference extends OverallDiameter {

	double tireCircumference1 = overallDiameter1 * 3.14; 
	double tireCircumference2 = overallDiameter2 * 3.14;
}
